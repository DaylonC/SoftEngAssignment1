# Node-Express-jQuery-AJAX-REST-API

Created using Node.js, Express.js, jQuery.js, AJAX and REST api

Created by Daylon Carse

# Installation in local

You need to have have Node.js and NPM in your local files

## To Install

npm install

## Run

'npm start' or 'nodemon app'

Code is running on 
+ http://localhost:3000/

## References

+ https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbHRvUWEyN3NlWFV2a08tRDRGMWg1cktFR0M4d3xBQ3Jtc0tudUVUWUZPLURhWVpXTDF4RFIweEI4VnRSVUJkSW96QjFRWDNsY3lfd3lDd0d3aHR6Vll6MU9SU0RFZ2FhVTVaS0d0Y3B0ZGZxdC1pYmNCRU96VmI2dUtfV284THRWSHV6dXduM1VOd3V2RmdlZFJiMA&q=https%3A%2F%2Fgithub.com%2Fmichaelcheng429%2Fajax-restful-api-tutorial

